
class Pair:
	vList: {}
	type: int = -1 #-1 - An invalid value type, 0 - Discrete value, 1 - Number value
