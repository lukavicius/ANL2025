'''
Created on Apr 21, 2022

@author: Dave de Jonge, IIIA-CSIC
'''
from micro_agent.micro_agent import MiCROAgent
def party():
    return MiCROAgent