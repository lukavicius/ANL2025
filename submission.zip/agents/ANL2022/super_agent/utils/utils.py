from time import time


def get_ms_current_time():
    return int(time() * 1000)
